#include "calcul.h"

int calcul(int e1, int e2)
{
    return e1 + e2;
}