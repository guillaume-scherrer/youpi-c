#pragma once

void lettresXYZ(char* str, float*tx, float*ty, float *tz, int* ttr, int*np); 