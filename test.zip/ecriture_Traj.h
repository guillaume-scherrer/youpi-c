#pragma once

void ecritureTraj(float* tt1, float* tt2, float* tt3, int*
ttr, int np);