#pragma once

char* conversion(int somme);