#define MAX_STRING_SIZE 25
#define MAX_ROMAN_NUMBER 4000
#define MAX_XYZ 5000
#define OFFSET_X 145
#define OFFSET_Z -139.5
#define CELL_X 11
#define CELL_Z 9
#define M_PI 3.141592653589793238
#define BACK_COLOR (SDL_Color){ 191, 191, 191, 255 }
#define BACK_SELECT_COLOR (SDL_Color){ 255, 255, 255, 255 }
#define FRONT_COLOR (SDL_Color){ 0, 0, 0, 255 }