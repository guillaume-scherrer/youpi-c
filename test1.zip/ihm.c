void ihm(int* e1, int* e2){
	
}