#pragma once

int inputCheck(int* tabE1E2);
int add(int* tabE1E2);
char* conversion(int somme);