#pragma once

void lettresTheta(float* tx, float* ty, float* tz, int np,
float* tt1, float* tt2, float* tt3);