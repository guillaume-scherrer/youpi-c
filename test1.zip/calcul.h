#pragma once

int calcul(int e1, int e2);