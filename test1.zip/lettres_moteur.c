#include "lettres_moteur.h"

void lettresMoteur(float* tt1, float* tt2, float* tt3, int*
ttr, int np){}